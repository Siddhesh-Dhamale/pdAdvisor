
<header class="d-flex justify-content-evenly align-items-baseline px-4 py-2 border-bottom">
    <div class="fw-semibold">Company Logo</div>

    <nav>
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link active custom-nav-link" href="#">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link custom-nav-link" href="#">Product</a>
            </li>
            <li class="nav-item">
                <a class="nav-link custom-nav-link" href="#">Solutions</a>
            </li>
            <li class="nav-item">
                <a class="nav-link custom-nav-link" href="#">About</a>
            </li>
            <li class="nav-item">
                <a class="nav-link custom-nav-link" href="#">Support</a>
            </li>
        </ul>
    </nav>

    <div class="d-flex align-items-center gap-5">
        <!-- ✅ Font Awesome Search Icon -->
        <i class="fas fa-search" style="font-size: 1.2rem;"></i>

        <a class="btn btn-danger rounded-lg px-4" href="#">Contact</a>
    </div>
</header>